import React, { useEffect,useState } from "react";
import Marzipano, { RectilinearView } from "marzipano";
import glassImage from './images/glass.png';
import { Menu, MenuItem } from "@mui/material";
import room360 from './images/room360.jpg';
const PanoViewer = () => {

	const [scene,setScene] = useState(null);
	const [viewer,setViewer] = useState(null);

	const [contextMenu, setContextMenu] = useState(null);

	const handleContextMenu = (event) => {
		event.preventDefault();
		setContextMenu(
		contextMenu === null
			? {
				mouseX: event.clientX - 2,
				mouseY: event.clientY - 4,
			}
			: // repeated contextmenu when it is already open closes it with Chrome 84 on Ubuntu
			// Other native context menus might behave different.
			// With this behavior we prevent contextmenu from the backdrop to re-locale existing context menus.
			null,
		);
	};

	const handleClose = () => {
		setContextMenu(null);
	};

	const createScene = (viewer) => {
		const source = Marzipano.ImageUrlSource.fromString(
			room360
		);
	
		const geometry = new Marzipano.EquirectGeometry([{ width: 4096 }]);
	
		const limiter = Marzipano.util.compose(
			Marzipano.RectilinearView.limit.vfov(0, 3),
			Marzipano.RectilinearView.limit.hfov(0, 3),
			Marzipano.RectilinearView.limit.pitch(-Math.PI / 2, Math.PI / 2)
		);
	
		const view = new Marzipano.RectilinearView(
			{
				yaw: 0,
				pitch: 0,
				fov: (100 * Math.PI) / 180
			},
			limiter
		);
	
		const scene = viewer.createScene({
			source: source,
			geometry: geometry,
			view: view,
			pinFirstLevel: true
		});
	
		return scene;
	}
	
	const createHotspot = (scene, hotspotElement) => {
		const hotspot = scene.hotspotContainer().createHotspot(hotspotElement, {
			yaw: 0,
			pitch: 0
		},
		{ perspective: { radius: 500, extraTransforms: "rotateX(5deg)" }}
		);
	
		return hotspot;
	}
	
	const addDrag = (element, hotspot, viewer) => {
		let lastX, lastY;
	
		const onMouseDown = (event) => {
			lastX = event.x;
			lastY = event.y;
	
			viewer.controls().disable();
	
			window.addEventListener("mousemove", onMouseMove);
			window.addEventListener("mouseup", onMouseUp);
		}
	
		const onMouseMove = (event) => {
			
			const {
				x: offsetX,
				y: offsetY
			} = viewer.domElement().getBoundingClientRect();
			const { x: elementX, y: elementY } = element.getBoundingClientRect();
			const deltaX = event.x - lastX;
			const deltaY = event.y - lastY;
			const x = deltaX + elementX - offsetX;
			const y = deltaY + elementY - offsetY;
			lastX = event.x;
			lastY = event.y;
			hotspot.setPosition(viewer.view().screenToCoordinates({ x, y }));
		}
	
		const onMouseUp = () => {
			viewer.controls().enable();
			console.info("Hotspot position", hotspot.position());
	
			window.removeEventListener("mousemove", onMouseMove);
			window.removeEventListener("mouseup", onMouseUp);
		}
	
		element.onmousedown = onMouseDown;
	}
	const createHotspotOnClick = (event,scene,viewer) => {
		event.preventDefault()
		const hotspotElement = createNewHosSpotElement();
		const hotspot = createHotspot(scene, hotspotElement);
		addDrag(hotspotElement, hotspot, viewer);
	

		const x = contextMenu ? contextMenu.mouseX : event.clientX;
		const y = contextMenu ? contextMenu.mouseY : event.clientY; 

		hotspot.setPosition(viewer.view().screenToCoordinates({ x, y }));
		
	}

	const createNewHosSpotElement = () => {
		const element = document.createElement("div");
		element.style.width = "100px";
		element.style.height = "100px";
		element.innerText = "Hotspot";
		element.style.backgroundColor = "blue";
		return element;
	}

	const handleCreateRectangle = (event,scene,viewer) => {
		if(!scene || !viewer) return;
		setContextMenu(null);
		createHotspotOnClick(event,scene,viewer)
	}

	useEffect(() => {
		const panoramaContainer = document.querySelector("#panorama-container");
		const viewer = new Marzipano.Viewer(panoramaContainer);
		const scene = createScene(viewer);
		setScene(scene)
		setViewer(viewer)
		// window.addEventListener("mousemove", () => panoramaContainer.removeEventListener('click',(e) => createHotspotOnClick(e,scene,viewer)));
		// window.addEventListener("mouseup", onMouseUp);

		scene.switchTo();
	}, []);
	
	return (
		<div
			id="panorama-container"
			style={{
				position: "absolute",
				top: 0,
				left: 0,
				width: "100%",
				height: "100%"
			}}
			onContextMenu={handleContextMenu}
		>
			{/* <div id="hotspot" style={{
				background: "red",
				width: "100px",
				height: "100px",
				color: "white",
				resize: "both",
			}}>
				Hello world
			</div> */}
			<Menu
				open={contextMenu !== null}
				onClose={handleClose}
				anchorReference="anchorPosition"
				anchorPosition={
				contextMenu !== null
					? { top: contextMenu.mouseY, left: contextMenu.mouseX }
					: undefined
				}
			>
				<MenuItem onClick={(e) => handleCreateRectangle(e,scene,viewer)}>Create Rectangale Div</MenuItem>
				{/* <MenuItem onClick={handleClose}>Print</MenuItem>
				<MenuItem onClick={handleClose}>Highlight</MenuItem>
				<MenuItem onClick={handleClose}>Email</MenuItem> */}
			</Menu>
		</div>
	);
};

export default PanoViewer;
